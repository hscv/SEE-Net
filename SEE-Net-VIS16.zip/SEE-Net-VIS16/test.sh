CUDA_VISIBLE_DEVICES=7 nohup python -u tools/demo.py --config experiments/siamban_r50_l234/config.yaml --snapshot experiments/siamban_r50_l234/snapshot/checkpoint_e30.pth --video_path /data/lizf/HOT/dataset/test/test_HSI/ > nohup.test.log 2>&1 &

